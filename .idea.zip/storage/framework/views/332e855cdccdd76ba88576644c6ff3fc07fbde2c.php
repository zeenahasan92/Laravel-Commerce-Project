<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Products</h1>

    <div class="row">
        <div class="col-md-12">

            <a href="/admin/products/add" class="btn btn-success">Add Product</a>
            <br><br>

            <table class="table table-bordered table-responsive">
                <thead>
                <tr class="warning">
                    <th class="text-center">Name</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Price</th>
                    <th class="text-center">Category</th>
                    <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center bold">
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->price); ?>$</td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td>
                            <a class="btn btn-danger" href="/admin/products/delete/<?php echo e($product->id); ?>">Delete
                                <span class="fa fa-remove"></span></a>
                            <a class="btn btn-primary" href="/admin/products/update/<?php echo e($product->id); ?>">Update
                                <span class="fa fa-edit"></span></a>
                            <a class="btn btn-warning" href="/admin/products/<?php echo e($product->id); ?>">View
                                <span class="fa fa-eye"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="text-center">
                <?php echo e($products->links()); ?>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>