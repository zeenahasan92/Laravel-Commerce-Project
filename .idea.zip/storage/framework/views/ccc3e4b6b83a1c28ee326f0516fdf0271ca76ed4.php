<?php $__env->startSection('title'); ?>
    View Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .avatar {
            border: 5px solid darkgray;
            -webkit-box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.75);
            -moz-box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.75);
            box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.75);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('users'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="section-title"><?php echo e($user->name); ?></h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <h4><b>Email :</b> <?php echo e($user->email); ?></h4>
                        </li>
                        <li class="list-group-item">
                            <h4><b>Register At : </b><?php echo e($user->created_at); ?></h4>
                        </li>
                        <li class="list-group-item">
                            <h4><b>Last Updated : </b><?php echo e($user->updated_at); ?></h4>
                        </li>
                    </ul>
                    <a class="btn btn-info " href="/admin/users">
                        <b>
                                Back To List
                                <i class="fa fa-arrow-left"></i>
                            </b>

                    </a>
                </div>
                <div class="col-md-6 text-center">
                    <div class="col-md-8 col-md-offset-2">
                        <img class="img-rounded img-thumbnail img-responsive" src="/<?php echo e(env('imagePath')); ?><?php echo e($user->avatar); ?>"
                             alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>