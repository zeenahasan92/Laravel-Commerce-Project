<?php $__env->startSection('title'); ?>
    Search
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/search.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="section-title">Search Results</h3>
        </div>
        <div class="panel-body">

            <div class="mb20">
                <?php if(isset($searchMax)): ?>
                    <h2 class="lead">
                        <strong class="text-danger">
                            <?php echo e($products->count()); ?>

                        </strong> results were found for the Price between
                        <strong class="text-danger"><?php echo e($search); ?> $</strong>
                        And
                        <strong class="text-danger"><?php echo e($searchMax); ?> $</strong>
                    </h2>
                <?php else: ?>
                    <h2 class="lead">
                        <strong class="text-danger">
                            <?php echo e($products->count()); ?>

                        </strong> results were found for the search for
                        <strong class="text-danger"><?php echo e($search); ?></strong>
                    </h2>
                <?php endif; ?>
            </div>

            <section class="col-xs-12 col-sm-6 col-md-12">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="search-result row">
                        <div class="col-xs-12 col-sm-12 col-md-3">
                            <a href="/product/view/<?php echo e($product->id); ?>" title="Lorem ipsum" class="thumbnail">
                                <img src="/<?php echo e(env('imagePath')); ?><?php echo e($product->image); ?>"
                                     alt="<?php echo e($product->name); ?>"/></a>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2">
                            <ul class="meta-search">
                                <li>
                                    <i class="glyphicon glyphicon-calendar"></i>
                                    <span>
                                        <?php echo e(Carbon\Carbon::parse($product->created_at)->format('Y-m-d')); ?>

                                    </span>
                                </li>
                                <li>
                                    <i class="glyphicon glyphicon-time"></i>
                                    <span>
                                       <?php echo e(Carbon\Carbon::parse($product->created_at)->format('H:m')); ?>

                                    </span>
                                </li>
                                <li>
                                    <i class="fa fa-money"></i>
                                    <span><?php echo e($product->price); ?></span>
                                </li>
                                <li>
                                    <i class="glyphicon glyphicon-tags"></i>
                                    <span><?php echo e($product->category->name); ?></span>
                                </li>

                            </ul>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-7 excerpet">
                            <h3><a href="/product/view/<?php echo e($product->id); ?>" title=""><?php echo e($product->name); ?></a></h3>
                            <p><?php echo e($product->description); ?></p>
                        </div>
                        <span class="clearfix borda"></span>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/vue.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>