<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('categories'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Delete "<?php echo e($category->name); ?>"</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="text-center">
                        <a href="/admin/categories" class="btn btn-primary">Back To List
                            <i class="fa fa-arrow-left"></i></a>
                        <button class="btn btn-danger" type="Submit">Delete
                                <i class="fa fa-remove"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>