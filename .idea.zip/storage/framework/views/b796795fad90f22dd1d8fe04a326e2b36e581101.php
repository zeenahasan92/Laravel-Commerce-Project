<?php $__env->startSection('title'); ?>
    Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('users'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

         <h1>Users</h1>
         <hr>
        <div class="col-12-md">
            <table class="table table-bordered table-responsive">
                <thead>
                <tr class="warning">
                    <th class="text-center">Name</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Created At</th>
                    <th class="text-center">Updated - At</th>
                    <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center bold">
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <td><?php echo e($user->updated_at); ?></td>
                        <td>
                            <a class="btn btn-danger" href="/admin/users/delete/<?php echo e($user->id); ?>">
                                Delete <span class="fa fa-remove"></span></a>
                            <a class="btn btn-warning" href="/admin/users/<?php echo e($user->id); ?>">View
                                <span class="fa fa-eye"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="text-center">
                <?php echo e($users->links()); ?>

            </div>

        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>