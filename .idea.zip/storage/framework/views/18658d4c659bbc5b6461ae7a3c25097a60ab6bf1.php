<?php $__env->startSection('title'); ?>
    View Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">View "<?php echo e($product->name); ?>"</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="form-group text-center">
                <h2>Quantity : <?php echo e($product->quantity); ?></h2>
            </div>

            <div class="form-group text-center">
                <h2>Category : <?php echo e($product->category->name); ?></h2>
            </div>

            <div class="form-group text-center">
                <h2>Price : <?php echo e($product->price); ?></h2>
            </div>

            <div class="form-group text-center">
                <img src="/<?php echo e(env('imagePath')); ?><?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
            </div>
            
            <div class="form-group text-center">
                <a href="/admin/products" class="btn btn-info">Back To List</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>