<?php $__env->startSection('title'); ?>
    Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('orders'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-danger">
        <div class="panel-heading">
            <h3 class="section-title">
                <i class="fa fa-shopping-cart"></i>
                Orders</h3>
        </div>
        <div class="panel-body">
            <table class="table table-hover table-bordered ">
                <thead>
                <tr class="danger">
                    <th class="text-center">Name</th>
                    <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><b><?php echo e($user->name); ?></b></td>
                        <td>
                            <a class="btn btn-primary" href="/admin/orders/<?php echo e($user->id); ?>">View User Order
                                <span class="fa fa-eye"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>