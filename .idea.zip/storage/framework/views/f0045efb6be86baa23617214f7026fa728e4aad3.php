<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Products</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">

            <form method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <input type="Text" name="name" class="form-control" placeholder="Product Name">
                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                         <strong><?php echo e($errors->first('name')); ?></strong>
                         </span>
                    <?php endif; ?>
                </div>


                <div class="form-group <?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
                    <input type="Text" name="quantity" class="form-control" placeholder="Quantity">
                    <?php if($errors->has('quantity')): ?>
                        <span class="help-block">
                         <strong><?php echo e($errors->first('quantity')); ?></strong>
                         </span>
                    <?php endif; ?>
                </div>


                <div class="form-group <?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                    <input type="Text" name="price" class="form-control" placeholder="Price in Dollar">
                    <?php if($errors->has('price')): ?>
                        <span class="help-block">
                         <strong><?php echo e($errors->first('price')); ?></strong>
                         </span>
                    <?php endif; ?>
                </div>


                <div class="form-group <?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                    <input type="file" name="image" class="form-control">
                    <?php if($errors->has('image')): ?>
                        <span class="help-block">
                         <strong><?php echo e($errors->first('image')); ?></strong>
                         </span>
                    <?php endif; ?>
                </div>


                <div class="form-group <?php echo e($errors->has('categories') ? ' has-error' : ''); ?>">
                    <select name="categories" class="form-control">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('categories')): ?>
                        <span class="help-block">
                         <strong><?php echo e($errors->first('categories')); ?></strong>
                         </span>
                    <?php endif; ?>
                </div>


                <div class="form-group">
                    <a class="btn btn-warning" href="/admin/products">Back To List</a>
                    <button class="btn btn-primary" type="Submit">Add</button>
                </div>


            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>