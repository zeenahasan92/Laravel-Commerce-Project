<?php $__env->startSection('title'); ?>
    Delete Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Delete "<?php echo e($product->name); ?>"</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form method="POST">
                <?php echo e(csrf_field()); ?>


                <div class="form-group text-center">
                    <h2>Quantity : <?php echo e($product->quantity); ?></h2>
                </div>

                <div class="form-group text-center">
                    <h2>Category : <?php echo e($product->category->name); ?></h2>
                </div>

                <div class="form-group text-center">
                    <img src="/<?php echo e(env('imagePath')); ?><?php echo e($product->image); ?>" width="200" height="200" alt="">
                </div>

                <div class="form-group">
                    <div class="text-center">
                        <a href="/admin/products" class="btn btn-info">Back To List</a>
                        <button class="btn btn-danger" type="Submit">Delete</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>