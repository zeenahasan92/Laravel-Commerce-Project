<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="section-title">Profile</h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <h4><b>Name : </b><?php echo e(Auth::user()->name); ?></h4>
                        </li>
                        <li class="list-group-item">
                            <h4><b>Email :</b> <?php echo e(Auth::user()->email); ?></h4>
                        </li>
                        <li class="list-group-item">
                            <h4><b>Register At : </b><?php echo e(Auth::user()->created_at); ?></h4>
                        </li>
                        <li class="list-group-item">
                            <h4><b>Last Updated : </b><?php echo e(Auth::user()->updated_at); ?></h4>
                        </li>
                    </ul>
                    <a class="btn btn-link form-control" href="/">
                        <h4><b>
                                Back To Simple
                                <i class="fa fa-external-link"></i>
                            </b>
                        </h4>
                    </a>
                </div>
                <div class="col-md-6">
                    <img class="img-rounded img-responsive" src="/<?php echo e(env('imagePath')); ?><?php echo e(Auth::user()->avatar); ?>"
                         alt="<?php echo e(Auth::user()->name); ?>">
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/vue.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>