<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('users'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .avatar{
            border: 5px solid darkgray;
            -webkit-box-shadow: 0px 0px 5px 2px rgba(0,0,0,0.75);
            -moz-box-shadow: 0px 0px 5px 2px rgba(0,0,0,0.75);
            box-shadow: 0px 0px 5px 2px rgba(0,0,0,0.75);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Delete "<?php echo e($user->name); ?>"</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
                    <div class="form-group text-center">
                        <h3>Email : <?php echo e($user->email); ?></h3>
                    </div>

                    <div class="form-group text-center">
                        <img src="/<?php echo e(env('imagePath')); ?><?php echo e($user->avatar); ?>" class="img-circle avatar" width="200" height="200" alt="<?php echo e($user->name); ?>">
                    </div>

            <form method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="text-center">
                        <a href="/admin/users" class="btn btn-info">Back To List</a>
                        <button class="btn btn-danger" type="Submit">Delete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>