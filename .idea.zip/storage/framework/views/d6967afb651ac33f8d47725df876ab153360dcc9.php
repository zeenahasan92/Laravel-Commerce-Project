<?php $__env->startSection('title'); ?>
    View Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="section-title"><?php echo e($product->name); ?></h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <h2>Quantity : <br>
                        <?php echo e($product->quantity); ?></h2>
                    <h3>Category : <br>
                        <?php echo e($product->category->name); ?></h3>
                    <h4>Price : <br>
                        <?php echo e($product->price); ?></h4>
                    <h4>Description : <br>
                        <?php echo e($product->description); ?></h4>
                    <div class="form-group">
                        <a href="/admin/products" class="btn btn-info">Back To List
                        <i class="fa fa-arrow-left"></i></a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img class="img-rounded product img-responsive pull-right"
                         src="/<?php echo e(env('imagePath')); ?><?php echo e($product->image); ?>"
                         alt="<?php echo e($product->name); ?>">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>