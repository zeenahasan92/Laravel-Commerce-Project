<?php $__env->startSection('title'); ?>
    Customer Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('orders'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .card {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center"><?php echo e($user->name); ?> Order</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card text-center">
                    <div class="card-block">
                        <h4 class="card-title"><?php echo e($product->name); ?></h4>
                        <p class="card-text">Price : <?php echo e($product->price); ?> $</p>
                        <p class="card-text">
                            <img width="100" height="100"
                                 class="img-thumbnail"
                                 src="/<?php echo e(env('imagePath')); ?><?php echo e($product->image); ?>"
                                 alt="<?php echo e($product->name); ?>">
                        </p>
                    </div>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-center">
                <a href="/admin/orders" class="btn btn-primary">Back To List</a>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>