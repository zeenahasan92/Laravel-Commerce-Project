<?php $__env->startSection('title'); ?>
    Update Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('categories'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Update "<?php echo e($category->name); ?>"</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="control-label bold">Update Category</label>
                    <div class="input-group">
                        <span class="input-group-addon bold">Category</span>
                        <input type="Text" value="<?php echo e($category->name); ?>" class="form-control" name="name">
                        <span class="input-group-btn">
                   <button class="btn btn-primary" type="Submit">update
                <i class="fa fa-edit"></i></button>
                </span>
                    </div>
                </div>
            </form>
            <a href="/admin/categories" class="btn btn-primary">Back To List
                <i class="fa fa-arrow-left"></i></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>