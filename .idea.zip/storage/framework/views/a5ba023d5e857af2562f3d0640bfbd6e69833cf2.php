<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/slider.css')); ?>">
    <style>
        .product {
            height: 200px;
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div v-for="(product,index) in products" v-if="index < 3" class="panel panel-default">
        <div class="panel-heading">
            <h3 class="section-title">
                <i class="fa fa-list-alt" aria-hidden="true"></i>
                {{ product.name }}</h3>
        </div>
        <div class="panel-body">
            <div class="col-md-4" v-for="(item,index) in product.products" v-if="index < 3">

                <img class="img-thumbnail product"
                     :src="'/uploaded_images/'+item.image"
                     :alt="item.name">


                <h3 class="text-center">{{ item.name }} -
                    <span style="color:maroon;font-weight: bold">$ {{ item.price }}</span>
                </h3>

                <p>{{ item.description }}</p>

                <?php if(Auth::guest()): ?>

                    <a :href="'/product/view/'+item.id" class="btn btn-primary form-control">
                        View <span class="fa fa-eye"></span>
                    </a>
                <?php else: ?>
                    <button @click="addToCart(item.id)" class="btn btn-success">
                        Add To Cart
                        <span class="fa fa-cart-plus"></span>
                    </button>

                    <a :href="'/product/view/'+item.id" class="btn btn-primary">
                        View <span class="fa fa-eye"></span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/vue.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>