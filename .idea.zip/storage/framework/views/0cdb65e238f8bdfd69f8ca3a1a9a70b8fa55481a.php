<?php $__env->startSection('title'); ?>
      Category Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('categories'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">"<?php echo e($products->first()->category->name); ?>" Products</h1>

    <div class="row">

        <div class="col-md-8 col-md-offset-2">

            <table class="table table-bordered ">
                <thead>
                <tr class="warning">
                    <th class="text-center">Name</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Category</th>
                    <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center bold">
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td>
                            <a class="btn btn-danger" href="/admin/products/delete/<?php echo e($product->id); ?>">Delete</a>
                            <a class="btn btn-primary" href="/admin/products/update/<?php echo e($product->id); ?>">Update</a>
                            <a class="btn btn-warning" href="/admin/products/<?php echo e($product->id); ?>">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>