<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('search.css')); ?>">
    <style>
        .product {
            max-height: 340px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="section-title"><?php echo e($product->name); ?></h3>
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <h2>Quantity : <br>
                        <?php echo e($product->quantity); ?></h2>
                    <h3>Category : <br>
                        <?php echo e($product->category->name); ?></h3>
                    <h4>Price : <br>
                        <?php echo e($product->price); ?></h4>
                    <h4>Description : <br>
                        <?php echo e($product->description); ?></h4>
                </div>
                <div class="col-md-6">
                    <img class="img-rounded product img-responsive pull-right" src="/<?php echo e(env('imagePath')); ?><?php echo e($product->image); ?>"
                         alt="<?php echo e($product->name); ?>">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/vue.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>