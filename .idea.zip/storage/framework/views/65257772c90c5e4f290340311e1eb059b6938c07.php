<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('categories'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Categories</h1>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">


            <form action="categories/add" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="control-label bold">Add Category</label>
                    <div class="input-group">
                        <span class="input-group-addon bold">Category</span>
                        <input type="Text" class="form-control" name="name">
                        <span class="input-group-btn">
                   <button class="btn btn-primary" type="Submit">Add</button>
                </span>
                    </div>
                </div>
            </form>


            <table class="table table-bordered ">
                <thead>
                <tr class="danger">
                    <th class="text-center">Id</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bold text-center">
                        <td><b><?php echo e($category->id); ?></b></td>
                        <td><b><?php echo e($category->name); ?></b></td>
                        <td>
                            <a class="btn btn-danger" href="categories/delete/<?php echo e($category->id); ?>">Delete
                                <span class="fa fa-remove"></span></a>
                            <a class="btn btn-primary" href="categories/update/<?php echo e($category->id); ?>">Update
                                <span class="fa fa-edit"></span></a>
                                <a class="btn btn-warning" <?php echo e(($category->products->count() != 0)?'':'disabled'); ?>

                                href="categories/<?php echo e($category->id); ?>">Products
                                    <span class="fa fa-eye"></span></a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


            <div class="text-center">
                <?php echo e($categories->links()); ?>

            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>