<?php $__env->startSection('title'); ?>
    Customer Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('orders'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .card {
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="section-title"><?php echo e($user->name); ?> Order</h3>
        </div>
        <div class="panel-body">
            <div class="list-group">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <b><?php echo e($product->name); ?></b>
                        <span style="color:maroon;"> $ <?php echo e($product->price); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center">

                <a href="/admin/orders" class="btn btn-primary">Back To List
                    <i class="fa fa-arrow-left"></i></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>