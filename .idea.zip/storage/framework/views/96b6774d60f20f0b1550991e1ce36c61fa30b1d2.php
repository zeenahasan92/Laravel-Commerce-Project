<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('products'); ?>
    active-link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="section-title">
                <i class="fa fa-product-hunt"></i>
                Products</h3>
        </div>

        <div class="panel-body">
            <a href="/admin/products/add" class="btn btn-primary">Add Product
            <i class="fa fa-plus"></i></a>
            <br><br>
            <table class="table table-hover table-bordered">
                <thead>
                <tr class="bg-primary">
                    <th class="text-center">Name</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Price</th>
                    <th class="text-center">Category</th>
                    <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center bold">
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->price); ?>$</td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td>
                            <a class="btn btn-danger" href="/admin/products/delete/<?php echo e($product->id); ?>">Delete
                                <span class="fa fa-remove"></span></a>
                            <a class="btn btn-primary" href="/admin/products/update/<?php echo e($product->id); ?>">Update
                                <span class="fa fa-edit"></span></a>
                            <a class="btn btn-warning" href="/admin/products/<?php echo e($product->id); ?>">View
                                <span class="fa fa-eye"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="text-center">
        <?php echo e($products->links()); ?>

    </div>









<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>